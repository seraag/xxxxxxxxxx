#define DEBUG
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using Microsoft.VisualBasic.CompilerServices;

namespace XWorm;

[DesignerGenerated]
public class Fun : Form
{
	private IContainer components;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Timer1")]
	private System.Windows.Forms.Timer _Timer1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton1")]
	private Guna2GradientButton _Guna2GradientButton1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton2")]
	private Guna2GradientButton _Guna2GradientButton2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton3")]
	private Guna2GradientButton _Guna2GradientButton3;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton4")]
	private Guna2GradientButton _Guna2GradientButton4;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton5")]
	private Guna2GradientButton _Guna2GradientButton5;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton6")]
	private Guna2GradientButton _Guna2GradientButton6;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton7")]
	private Guna2GradientButton _Guna2GradientButton7;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton8")]
	private Guna2GradientButton _Guna2GradientButton8;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton9")]
	private Guna2GradientButton _Guna2GradientButton9;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton10")]
	private Guna2GradientButton _Guna2GradientButton10;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton11")]
	private Guna2GradientButton _Guna2GradientButton11;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton12")]
	private Guna2GradientButton _Guna2GradientButton12;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton13")]
	private Guna2GradientButton _Guna2GradientButton13;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton14")]
	private Guna2GradientButton _Guna2GradientButton14;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton15")]
	private Guna2GradientButton _Guna2GradientButton15;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton16")]
	private Guna2GradientButton _Guna2GradientButton16;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton17")]
	private Guna2GradientButton _Guna2GradientButton17;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton18")]
	private Guna2GradientButton _Guna2GradientButton18;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton20")]
	private Guna2GradientButton _Guna2GradientButton20;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton19")]
	private Guna2GradientButton _Guna2GradientButton19;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton21")]
	private Guna2GradientButton _Guna2GradientButton21;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Guna2GradientButton22")]
	private Guna2GradientButton _Guna2GradientButton22;

	public GClass5 gclass5_0;

	[field: AccessedThroughProperty("Label11")]
	public Label Label11
	;

	[field: AccessedThroughProperty("Label10")]
	public Label Label10
	;
	[field: AccessedThroughProperty("Label9")]
	public Label Label9
	;

	[field: AccessedThroughProperty("Label8")]
	public Label Label8
	;

	[field: AccessedThroughProperty("Label6")]
	public Label Label6
	;

	[field: AccessedThroughProperty("Label5")]
	public Label Label5
	;

	[field: AccessedThroughProperty("Label4")]
	public Label Label4
	;

	[field: AccessedThroughProperty("Label3")]
	public Label Label3
	;

	[field: AccessedThroughProperty("Label2")]
	public Label Label2
	;

	[field: AccessedThroughProperty("Label1")]
	public Label Label1
	;

	public System.Windows.Forms.Timer Timer1;


	public Guna2GradientButton Guna2GradientButton1
	;

	public Guna2GradientButton Guna2GradientButton2
	;

	public Guna2GradientButton Guna2GradientButton3
	;

	public Guna2GradientButton Guna2GradientButton4
	;

	public Guna2GradientButton Guna2GradientButton5
;

	public Guna2GradientButton Guna2GradientButton6
	;

	public Guna2GradientButton Guna2GradientButton7
	;

	public Guna2GradientButton Guna2GradientButton8
;

	public Guna2GradientButton Guna2GradientButton9
;

	public Guna2GradientButton Guna2GradientButton10
	;

	public Guna2GradientButton Guna2GradientButton11
	;

	public Guna2GradientButton Guna2GradientButton12
	;
	public Guna2GradientButton Guna2GradientButton13
	;

	public Guna2GradientButton Guna2GradientButton14
	;

	public Guna2GradientButton Guna2GradientButton15
	;

	public Guna2GradientButton Guna2GradientButton16
	;


	[field: AccessedThroughProperty("Label12")]
	public Label Label12
	;

	public Guna2GradientButton Guna2GradientButton17
;

	public Guna2GradientButton Guna2GradientButton18
	;

	public Guna2GradientButton Guna2GradientButton20
	;

	public Guna2GradientButton Guna2GradientButton19
;
	public Guna2GradientButton Guna2GradientButton21
;

	[field: AccessedThroughProperty("Guna2TextBox1")]
	public Guna2TextBox Guna2TextBox1
	;

	public Guna2GradientButton Guna2GradientButton22
	;

	public Fun()
	{
		base.FormClosing += Fun_FormClosing;
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(XWorm.Fun));
		this.Label11 = new System.Windows.Forms.Label();
		this.Label10 = new System.Windows.Forms.Label();
		this.Label9 = new System.Windows.Forms.Label();
		this.Label8 = new System.Windows.Forms.Label();
		this.Label6 = new System.Windows.Forms.Label();
		this.Label5 = new System.Windows.Forms.Label();
		this.Label4 = new System.Windows.Forms.Label();
		this.Label3 = new System.Windows.Forms.Label();
		this.Label2 = new System.Windows.Forms.Label();
		this.Label1 = new System.Windows.Forms.Label();
		this.Timer1 = new System.Windows.Forms.Timer(this.components);
		this.Guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton5 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton9 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton10 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton11 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton12 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton13 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton14 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton15 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton16 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Label12 = new System.Windows.Forms.Label();
		this.Guna2GradientButton17 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton18 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton20 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton19 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2GradientButton21 = new Guna.UI2.WinForms.Guna2GradientButton();
		this.Guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
		this.Guna2GradientButton22 = new Guna.UI2.WinForms.Guna2GradientButton();
		base.SuspendLayout();
		this.Timer1.Tick += new System.EventHandler(Timer1_Tick);
		this.Guna2GradientButton1.Click += new System.EventHandler(Guna2GradientButton1_Click);
		this.Guna2GradientButton2.Click += new System.EventHandler(Guna2GradientButton2_Click);
		this.Guna2GradientButton3.Click += new System.EventHandler(Guna2GradientButton3_Click);
		this.Guna2GradientButton4.Click += new System.EventHandler(Guna2GradientButton4_Click);
		this.Guna2GradientButton5.Click += new System.EventHandler(Guna2GradientButton5_Click);
		this.Guna2GradientButton6.Click += new System.EventHandler(Guna2GradientButton6_Click);
		this.Guna2GradientButton7.Click += new System.EventHandler(Guna2GradientButton7_Click);
		this.Guna2GradientButton8.Click += new System.EventHandler(Guna2GradientButton8_Click);
		this.Guna2GradientButton9.Click += new System.EventHandler(Guna2GradientButton9_Click);
		this.Guna2GradientButton10.Click += new System.EventHandler(Guna2GradientButton10_Click);
		this.Guna2GradientButton11.Click += new System.EventHandler(Guna2GradientButton11_Click);
		this.Guna2GradientButton12.Click += new System.EventHandler(Guna2GradientButton12_Click);
		this.Guna2GradientButton13.Click += new System.EventHandler(Guna2GradientButton13_Click);
		this.Guna2GradientButton14.Click += new System.EventHandler(Guna2GradientButton14_Click);
		this.Guna2GradientButton15.Click += new System.EventHandler(Guna2GradientButton15_Click);
		this.Guna2GradientButton16.Click += new System.EventHandler(Guna2GradientButton16_Click);
		this.Guna2GradientButton17.Click += new System.EventHandler(Guna2GradientButton17_Click);
		this.Guna2GradientButton18.Click += new System.EventHandler(Guna2GradientButton18_Click);
		this.Guna2GradientButton19.Click += new System.EventHandler(Guna2GradientButton19_Click);
		this.Guna2GradientButton20.Click += new System.EventHandler(Guna2GradientButton20_Click);
		this.Guna2GradientButton21.Click += new System.EventHandler(Guna2GradientButton21_Click);
		this.Guna2GradientButton22.Click += new System.EventHandler(Guna2GradientButton22_Click);
		this.Label11.AutoSize = true;
		this.Label11.ForeColor = System.Drawing.Color.Black;
		this.Label11.Location = new System.Drawing.Point(112, 189);
		this.Label11.Name = "Label11";
		this.Label11.Size = new System.Drawing.Size(48, 13);
		this.Label11.TabIndex = 65;
		this.Label11.Text = "Volume :";
		this.Label10.AutoSize = true;
		this.Label10.ForeColor = System.Drawing.Color.Black;
		this.Label10.Location = new System.Drawing.Point(11, 189);
		this.Label10.Name = "Label10";
		this.Label10.Size = new System.Drawing.Size(71, 13);
		this.Label10.TabIndex = 61;
		this.Label10.Text = "SwapMouse :";
		this.Label9.AutoSize = true;
		this.Label9.ForeColor = System.Drawing.Color.Black;
		this.Label9.Location = new System.Drawing.Point(209, 106);
		this.Label9.Name = "Label9";
		this.Label9.Size = new System.Drawing.Size(65, 13);
		this.Label9.TabIndex = 58;
		this.Label9.Text = "TrayNotify :";
		this.Label8.AutoSize = true;
		this.Label8.ForeColor = System.Drawing.Color.Black;
		this.Label8.Location = new System.Drawing.Point(311, 19);
		this.Label8.Name = "Label8";
		this.Label8.Size = new System.Drawing.Size(54, 13);
		this.Label8.TabIndex = 55;
		this.Label8.Text = "Explorer :";
		this.Label6.AutoSize = true;
		this.Label6.ForeColor = System.Drawing.Color.Black;
		this.Label6.Location = new System.Drawing.Point(209, 19);
		this.Label6.Name = "Label6";
		this.Label6.Size = new System.Drawing.Size(38, 13);
		this.Label6.TabIndex = 49;
		this.Label6.Text = "Start :";
		this.Label5.AutoSize = true;
		this.Label5.ForeColor = System.Drawing.Color.Black;
		this.Label5.Location = new System.Drawing.Point(11, 106);
		this.Label5.Name = "Label5";
		this.Label5.Size = new System.Drawing.Size(47, 13);
		this.Label5.TabIndex = 46;
		this.Label5.Text = "Screen :";
		this.Label4.AutoSize = true;
		this.Label4.ForeColor = System.Drawing.Color.Black;
		this.Label4.Location = new System.Drawing.Point(311, 106);
		this.Label4.Name = "Label4";
		this.Label4.Size = new System.Drawing.Size(79, 13);
		this.Label4.TabIndex = 43;
		this.Label4.Text = "DesktopIcons :";
		this.Label3.AutoSize = true;
		this.Label3.ForeColor = System.Drawing.Color.Black;
		this.Label3.Location = new System.Drawing.Point(209, 189);
		this.Label3.Name = "Label3";
		this.Label3.Size = new System.Drawing.Size(68, 13);
		this.Label3.TabIndex = 42;
		this.Label3.Text = "Text Speak :";
		this.Label2.AutoSize = true;
		this.Label2.ForeColor = System.Drawing.Color.Black;
		this.Label2.Location = new System.Drawing.Point(112, 19);
		this.Label2.Name = "Label2";
		this.Label2.Size = new System.Drawing.Size(52, 13);
		this.Label2.TabIndex = 37;
		this.Label2.Text = "TaskBar :";
		this.Label1.AutoSize = true;
		this.Label1.ForeColor = System.Drawing.Color.Black;
		this.Label1.Location = new System.Drawing.Point(11, 19);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(62, 13);
		this.Label1.TabIndex = 34;
		this.Label1.Text = "CD ROOM :";
		this.Timer1.Enabled = true;
		this.Timer1.Interval = 1000;
		this.Guna2GradientButton1.BorderRadius = 4;
		this.Guna2GradientButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton1.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton1.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton1.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton1.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton1.Location = new System.Drawing.Point(14, 35);
		this.Guna2GradientButton1.Name = "Guna2GradientButton1";
		this.Guna2GradientButton1.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton1.TabIndex = 69;
		this.Guna2GradientButton1.Text = "Open";
		this.Guna2GradientButton2.BorderRadius = 4;
		this.Guna2GradientButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton2.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton2.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton2.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton2.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton2.Location = new System.Drawing.Point(14, 64);
		this.Guna2GradientButton2.Name = "Guna2GradientButton2";
		this.Guna2GradientButton2.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton2.TabIndex = 70;
		this.Guna2GradientButton2.Text = "Close";
		this.Guna2GradientButton3.BorderRadius = 4;
		this.Guna2GradientButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton3.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton3.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton3.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton3.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton3.Location = new System.Drawing.Point(115, 64);
		this.Guna2GradientButton3.Name = "Guna2GradientButton3";
		this.Guna2GradientButton3.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton3.TabIndex = 72;
		this.Guna2GradientButton3.Text = "Hide";
		this.Guna2GradientButton4.BorderRadius = 4;
		this.Guna2GradientButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton4.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton4.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton4.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton4.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton4.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton4.Location = new System.Drawing.Point(115, 35);
		this.Guna2GradientButton4.Name = "Guna2GradientButton4";
		this.Guna2GradientButton4.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton4.TabIndex = 71;
		this.Guna2GradientButton4.Text = "Show";
		this.Guna2GradientButton5.BorderRadius = 4;
		this.Guna2GradientButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton5.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton5.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton5.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton5.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton5.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton5.Location = new System.Drawing.Point(212, 64);
		this.Guna2GradientButton5.Name = "Guna2GradientButton5";
		this.Guna2GradientButton5.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton5.TabIndex = 74;
		this.Guna2GradientButton5.Text = "Hide";
		this.Guna2GradientButton6.BorderRadius = 4;
		this.Guna2GradientButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton6.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton6.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton6.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton6.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton6.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton6.Location = new System.Drawing.Point(212, 35);
		this.Guna2GradientButton6.Name = "Guna2GradientButton6";
		this.Guna2GradientButton6.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton6.TabIndex = 73;
		this.Guna2GradientButton6.Text = "Show";
		this.Guna2GradientButton7.BorderRadius = 4;
		this.Guna2GradientButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton7.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton7.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton7.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton7.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton7.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton7.Location = new System.Drawing.Point(314, 64);
		this.Guna2GradientButton7.Name = "Guna2GradientButton7";
		this.Guna2GradientButton7.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton7.TabIndex = 76;
		this.Guna2GradientButton7.Text = "Start";
		this.Guna2GradientButton8.BorderRadius = 4;
		this.Guna2GradientButton8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton8.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton8.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton8.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton8.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton8.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton8.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton8.Location = new System.Drawing.Point(314, 35);
		this.Guna2GradientButton8.Name = "Guna2GradientButton8";
		this.Guna2GradientButton8.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton8.TabIndex = 75;
		this.Guna2GradientButton8.Text = "Kill";
		this.Guna2GradientButton9.BorderRadius = 4;
		this.Guna2GradientButton9.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton9.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton9.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton9.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton9.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton9.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton9.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton9.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton9.Location = new System.Drawing.Point(314, 151);
		this.Guna2GradientButton9.Name = "Guna2GradientButton9";
		this.Guna2GradientButton9.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton9.TabIndex = 78;
		this.Guna2GradientButton9.Text = "Hide";
		this.Guna2GradientButton10.BorderRadius = 4;
		this.Guna2GradientButton10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton10.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton10.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton10.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton10.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton10.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton10.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton10.Location = new System.Drawing.Point(314, 122);
		this.Guna2GradientButton10.Name = "Guna2GradientButton10";
		this.Guna2GradientButton10.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton10.TabIndex = 77;
		this.Guna2GradientButton10.Text = "Show";
		this.Guna2GradientButton11.BorderRadius = 4;
		this.Guna2GradientButton11.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton11.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton11.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton11.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton11.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton11.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton11.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton11.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton11.Location = new System.Drawing.Point(14, 234);
		this.Guna2GradientButton11.Name = "Guna2GradientButton11";
		this.Guna2GradientButton11.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton11.TabIndex = 80;
		this.Guna2GradientButton11.Text = "Swap";
		this.Guna2GradientButton12.BorderRadius = 4;
		this.Guna2GradientButton12.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton12.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton12.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton12.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton12.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton12.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton12.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton12.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton12.Location = new System.Drawing.Point(14, 205);
		this.Guna2GradientButton12.Name = "Guna2GradientButton12";
		this.Guna2GradientButton12.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton12.TabIndex = 79;
		this.Guna2GradientButton12.Text = "Normal";
		this.Guna2GradientButton13.BorderRadius = 4;
		this.Guna2GradientButton13.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton13.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton13.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton13.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton13.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton13.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton13.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton13.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton13.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton13.Location = new System.Drawing.Point(14, 151);
		this.Guna2GradientButton13.Name = "Guna2GradientButton13";
		this.Guna2GradientButton13.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton13.TabIndex = 82;
		this.Guna2GradientButton13.Text = "Off";
		this.Guna2GradientButton14.BorderRadius = 4;
		this.Guna2GradientButton14.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton14.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton14.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton14.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton14.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton14.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton14.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton14.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton14.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton14.Location = new System.Drawing.Point(14, 122);
		this.Guna2GradientButton14.Name = "Guna2GradientButton14";
		this.Guna2GradientButton14.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton14.TabIndex = 81;
		this.Guna2GradientButton14.Text = "On";
		this.Guna2GradientButton15.BorderRadius = 4;
		this.Guna2GradientButton15.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton15.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton15.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton15.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton15.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton15.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton15.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton15.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton15.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton15.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton15.Location = new System.Drawing.Point(115, 151);
		this.Guna2GradientButton15.Name = "Guna2GradientButton15";
		this.Guna2GradientButton15.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton15.TabIndex = 85;
		this.Guna2GradientButton15.Text = "Hide";
		this.Guna2GradientButton16.BorderRadius = 4;
		this.Guna2GradientButton16.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton16.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton16.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton16.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton16.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton16.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton16.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton16.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton16.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton16.Location = new System.Drawing.Point(115, 122);
		this.Guna2GradientButton16.Name = "Guna2GradientButton16";
		this.Guna2GradientButton16.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton16.TabIndex = 84;
		this.Guna2GradientButton16.Text = "Show";
		this.Label12.AutoSize = true;
		this.Label12.ForeColor = System.Drawing.Color.Black;
		this.Label12.Location = new System.Drawing.Point(112, 106);
		this.Label12.Name = "Label12";
		this.Label12.Size = new System.Drawing.Size(39, 13);
		this.Label12.TabIndex = 83;
		this.Label12.Text = "Clock :";
		this.Guna2GradientButton17.BorderRadius = 4;
		this.Guna2GradientButton17.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton17.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton17.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton17.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton17.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton17.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton17.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton17.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton17.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton17.Location = new System.Drawing.Point(212, 151);
		this.Guna2GradientButton17.Name = "Guna2GradientButton17";
		this.Guna2GradientButton17.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton17.TabIndex = 87;
		this.Guna2GradientButton17.Text = "Hide";
		this.Guna2GradientButton18.BorderRadius = 4;
		this.Guna2GradientButton18.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton18.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton18.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton18.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton18.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton18.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton18.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton18.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton18.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton18.Location = new System.Drawing.Point(212, 122);
		this.Guna2GradientButton18.Name = "Guna2GradientButton18";
		this.Guna2GradientButton18.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton18.TabIndex = 86;
		this.Guna2GradientButton18.Text = "Show";
		this.Guna2GradientButton20.BorderRadius = 4;
		this.Guna2GradientButton20.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton20.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton20.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton20.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton20.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton20.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton20.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton20.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton20.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton20.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton20.Location = new System.Drawing.Point(115, 205);
		this.Guna2GradientButton20.Name = "Guna2GradientButton20";
		this.Guna2GradientButton20.Size = new System.Drawing.Size(31, 21);
		this.Guna2GradientButton20.TabIndex = 88;
		this.Guna2GradientButton20.Text = "+";
		this.Guna2GradientButton19.BorderRadius = 4;
		this.Guna2GradientButton19.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton19.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton19.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton19.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton19.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton19.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton19.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton19.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton19.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton19.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton19.Location = new System.Drawing.Point(163, 205);
		this.Guna2GradientButton19.Name = "Guna2GradientButton19";
		this.Guna2GradientButton19.Size = new System.Drawing.Size(31, 21);
		this.Guna2GradientButton19.TabIndex = 89;
		this.Guna2GradientButton19.Text = "-";
		this.Guna2GradientButton21.BorderRadius = 4;
		this.Guna2GradientButton21.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton21.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton21.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton21.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton21.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton21.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton21.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton21.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton21.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton21.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton21.Location = new System.Drawing.Point(115, 234);
		this.Guna2GradientButton21.Name = "Guna2GradientButton21";
		this.Guna2GradientButton21.Size = new System.Drawing.Size(76, 21);
		this.Guna2GradientButton21.TabIndex = 90;
		this.Guna2GradientButton21.Text = "MUTE";
		this.Guna2TextBox1.BorderColor = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2TextBox1.BorderRadius = 3;
		this.Guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
		this.Guna2TextBox1.DefaultText = "Hello World";
		this.Guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.Guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.Guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.Guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.Guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		this.Guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2TextBox1.ForeColor = System.Drawing.Color.Black;
		this.Guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		this.Guna2TextBox1.Location = new System.Drawing.Point(212, 205);
		this.Guna2TextBox1.Name = "Guna2TextBox1";
		this.Guna2TextBox1.PasswordChar = '\0';
		this.Guna2TextBox1.PlaceholderForeColor = System.Drawing.Color.Black;
		this.Guna2TextBox1.PlaceholderText = "";
		this.Guna2TextBox1.SelectedText = "";
		this.Guna2TextBox1.Size = new System.Drawing.Size(188, 21);
		this.Guna2TextBox1.TabIndex = 99;
		this.Guna2GradientButton22.BorderRadius = 4;
		this.Guna2GradientButton22.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton22.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.Guna2GradientButton22.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton22.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(169, 169, 169);
		this.Guna2GradientButton22.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.Guna2GradientButton22.FillColor2 = System.Drawing.Color.FromArgb(40, 192, 182);
		this.Guna2GradientButton22.Font = new System.Drawing.Font("Segoe UI", 9f);
		this.Guna2GradientButton22.ForeColor = System.Drawing.Color.White;
		this.Guna2GradientButton22.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
		this.Guna2GradientButton22.ImageSize = new System.Drawing.Size(17, 17);
		this.Guna2GradientButton22.Location = new System.Drawing.Point(212, 234);
		this.Guna2GradientButton22.Name = "Guna2GradientButton22";
		this.Guna2GradientButton22.Size = new System.Drawing.Size(188, 21);
		this.Guna2GradientButton22.TabIndex = 100;
		this.Guna2GradientButton22.Text = "Speak";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.Color.White;
		base.ClientSize = new System.Drawing.Size(409, 277);
		base.Controls.Add(this.Guna2GradientButton22);
		base.Controls.Add(this.Guna2TextBox1);
		base.Controls.Add(this.Guna2GradientButton21);
		base.Controls.Add(this.Guna2GradientButton19);
		base.Controls.Add(this.Guna2GradientButton20);
		base.Controls.Add(this.Guna2GradientButton17);
		base.Controls.Add(this.Guna2GradientButton18);
		base.Controls.Add(this.Guna2GradientButton15);
		base.Controls.Add(this.Guna2GradientButton16);
		base.Controls.Add(this.Label12);
		base.Controls.Add(this.Guna2GradientButton13);
		base.Controls.Add(this.Guna2GradientButton14);
		base.Controls.Add(this.Guna2GradientButton11);
		base.Controls.Add(this.Guna2GradientButton12);
		base.Controls.Add(this.Guna2GradientButton9);
		base.Controls.Add(this.Guna2GradientButton10);
		base.Controls.Add(this.Guna2GradientButton7);
		base.Controls.Add(this.Guna2GradientButton8);
		base.Controls.Add(this.Guna2GradientButton5);
		base.Controls.Add(this.Guna2GradientButton6);
		base.Controls.Add(this.Guna2GradientButton3);
		base.Controls.Add(this.Guna2GradientButton4);
		base.Controls.Add(this.Guna2GradientButton2);
		base.Controls.Add(this.Guna2GradientButton1);
		base.Controls.Add(this.Label11);
		base.Controls.Add(this.Label10);
		base.Controls.Add(this.Label9);
		base.Controls.Add(this.Label8);
		base.Controls.Add(this.Label6);
		base.Controls.Add(this.Label5);
		base.Controls.Add(this.Label4);
		base.Controls.Add(this.Label3);
		base.Controls.Add(this.Label2);
		base.Controls.Add(this.Label1);
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		base.Name = "Fun";
		this.Text = "Pastime";
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void Fun_FormClosing(object sender, FormClosingEventArgs e)
	{
		method_0("ClFun");
	}

	public object method_0(string MSG)
	{
		byte[] array = Module0.smethod_6(MSG);
		GClass5 gClass = gclass5_0;
		ThreadPool.QueueUserWorkItem([SpecialName][DebuggerHidden] (object a0) =>
		{
			gClass.method_1((byte[])a0);
		}, array);
		object result = default(object);
		return result;
	}

	private void Timer1_Tick(object sender, EventArgs e)
	{
		try
		{
			if (!gclass5_0.bool_0)
			{
				Close();
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Debug.WriteLine(ex.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void Guna2GradientButton1_Click(object sender, EventArgs e)
	{
		method_0("openCD");
	}

	private void Guna2GradientButton2_Click(object sender, EventArgs e)
	{
		method_0("closeCD");
	}

	private void Guna2GradientButton4_Click(object sender, EventArgs e)
	{
		method_0("TaskShow");
	}

	private void Guna2GradientButton3_Click(object sender, EventArgs e)
	{
		method_0("Taskhide");
	}

	private void Guna2GradientButton6_Click(object sender, EventArgs e)
	{
		method_0("showstart");
	}

	private void Guna2GradientButton5_Click(object sender, EventArgs e)
	{
		method_0("hidestart");
	}

	private void Guna2GradientButton8_Click(object sender, EventArgs e)
	{
		method_0("KillEXP");
	}

	private void Guna2GradientButton7_Click(object sender, EventArgs e)
	{
		method_0("STEXP");
	}

	private void Guna2GradientButton10_Click(object sender, EventArgs e)
	{
		method_0("showDESK");
	}

	private void Guna2GradientButton9_Click(object sender, EventArgs e)
	{
		method_0("hideDESK");
	}

	private void Guna2GradientButton12_Click(object sender, EventArgs e)
	{
		method_0("SWMouseD");
	}

	private void Guna2GradientButton11_Click(object sender, EventArgs e)
	{
		method_0("SWMouseE");
	}

	private void Guna2GradientButton14_Click(object sender, EventArgs e)
	{
		method_0("ScreenON");
	}

	private void Guna2GradientButton13_Click(object sender, EventArgs e)
	{
		method_0("ScreenOFF");
	}

	private void Guna2GradientButton16_Click(object sender, EventArgs e)
	{
		method_0("showClock");
	}

	private void Guna2GradientButton15_Click(object sender, EventArgs e)
	{
		method_0("hideClock");
	}

	private void Guna2GradientButton18_Click(object sender, EventArgs e)
	{
		method_0("showTray");
	}

	private void Guna2GradientButton17_Click(object sender, EventArgs e)
	{
		method_0("hideTray");
	}

	private void Guna2GradientButton20_Click(object sender, EventArgs e)
	{
		method_0("VUP");
	}

	private void Guna2GradientButton19_Click(object sender, EventArgs e)
	{
		method_0("VDWM");
	}

	private void Guna2GradientButton21_Click(object sender, EventArgs e)
	{
		method_0("VMUT");
	}

	private void Guna2GradientButton22_Click(object sender, EventArgs e)
	{
		byte[] array = Module0.smethod_6("speak" + GClass19.string_0 + Guna2TextBox1.Text.ToString());
		GClass5 gClass = gclass5_0;
		ThreadPool.QueueUserWorkItem([SpecialName][DebuggerHidden] (object a0) =>
		{
			gClass.method_1((byte[])a0);
		}, array);
	}
}