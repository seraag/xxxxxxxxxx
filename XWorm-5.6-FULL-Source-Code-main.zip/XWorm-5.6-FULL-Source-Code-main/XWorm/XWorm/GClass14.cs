namespace XWorm;

public class GClass14 : GClass12
{
	public string sUrl { get; set; }

	public string sTitle { get; set; }
}