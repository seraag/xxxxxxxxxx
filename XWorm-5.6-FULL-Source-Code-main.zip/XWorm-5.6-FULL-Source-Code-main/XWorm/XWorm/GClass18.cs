namespace XWorm;

public class GClass18 : GClass12
{
	public string sUrl { get; set; }

	public string sTitle { get; set; }

	public int iCount { get; set; }
}