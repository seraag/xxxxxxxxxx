using System.Collections.Generic;

namespace XWorm;

public class GClass9
{
	public byte[] _msgPack;

	public string _id;

	public List<string> strings_0;

	public GClass9(byte[] _msgPack, string _id)
	{
		this._msgPack = _msgPack;
		this._id = _id;
		strings_0 = new List<string>();
	}
}