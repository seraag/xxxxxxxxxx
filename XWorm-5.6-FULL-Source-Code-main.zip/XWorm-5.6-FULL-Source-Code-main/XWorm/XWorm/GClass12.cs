namespace XWorm;

public class GClass12
{
	public string type { get; set; }
}