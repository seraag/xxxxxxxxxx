using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("XWorm")]
[assembly: AssemblyDescription("XCoder")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("XWorm")]
[assembly: AssemblyCopyright("Copyright ©  2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("da0e7b82-9a56-4026-af48-52629b0d254b")]
[assembly: AssemblyFileVersion("5.6.0.0")]
[assembly: AssemblyVersion("5.6.0.0")]
