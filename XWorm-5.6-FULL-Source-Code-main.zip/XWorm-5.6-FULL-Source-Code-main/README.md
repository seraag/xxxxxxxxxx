# XWorm V5.6 Edition

<b>

This Project Contains XWorm V5.6 FULL Source Codes

## Compilation and Usage

- Download the project to your computer.
- Extract the Project to a Folder.
- Download Visual Studio to your computer
- Open the solution file (.sln).
- Select **Build Solution** from the **Build** menu.


Enjoy!
</b>

## Features

- **Information**
- **TCP Connections**
- **ActiveWindows**
- **StartupManager**
- **Registry Editor**
- **Process Manager**
- **Clipboard Manager**
- **Shell**
- **Installed Programs**
- **DDos Attack**
- **VB.Net Compiler**
- **File Manager**
- **WebCam (AutoSave)**
- **Multi screen support**
- **Change Group Name**
- **Support All Systems**
- **Extract Video Thumbnail (File manager)**
- **Run HVNC In Memory**
- **Microphone**

- **System Sound**
- **You can scroll up/down on some apps (Monitor - HVNC)**
  <b>
- Monitor

  - Mouse
  - Keyboard
  - AutoSave
  - Window

- RunFile

  - **Disk:** Run Directly on Disc
  - **Link:** Run with Link
  - **Memory:**
  - **RunPE:**

- Open Url

  - Visible
  - Invisible

- Location Manager

  - GPS
  - IP

- Client

  - Restart
  - Close
  - Uninstall
  - Update
  - Block
  - Note

- Power

  - Shutdown
  - Restart
  - Logoff

- Options

  - BlankScreen (Enable - Disable)
  - TaskMgr (Enable - Disable)
  - Regedit (Enable - Disable)
  - UAC (Enable - Disable)
  - Firewall (Enable - Disable)
  - Windows Update (Enable - Disable)
  - Invoke-BSOD
  - ResetScale
  - .Net 3.5 Install
  - RemovePlugins
  - DeleteRestore

- Password Recovery

  - Passwords
  - Cookies
  - CreditCards
  - Bookmarks
  - Downloads
  - Keywords
  - History
  - Autofill
  - All-In-One
  - Discord Tokens
  - TelegramSession
  - ProductKey
  - MetaMask
  - InternetExplorer
  - FileZilla
  - Wifi Keys

- Pastime

  - CD ROOM (Open - Close)

  - DesktopIcons (Show - Hide)

  - SwapMouse (Swap - Normal)

  - TaskBar (Show - Hide)

  - Screen (ON - OFF)

  - Volume (Up - Down - MUTE)

  - Start (Show - Hide)

  - Clock [Show - Hide]

  - Text Speak

  - Explorer (Start - Kill)

  - TrayNotify (Show - Hide)

- Extra 1

  - ReportWindow

  - Performance

  - Edit Hosts

  - KeyLogger (Offline - Online)

  - Client Chat

  - FileSeacher

  - Commands

  - MessageBox / BallonTooltip

  - UAC Bypass (RunAs - Cmstp - Fodhelper)

- Extra 2

  - Ransomware [Encrypt - Decrypt]

  - Reverse Proxy

  - Ngrok Installer

  - HVNC | CommandPrompt - PowerShell - explorer | | EdgeBrowser - BraveBrowser - FireFoxBrowser - ChromeBrowser | [CloneProfile]

  - Hidden RDP

  - Hidden Apps

  - Hidden Browser

  - Bot killer

  - WDKiller

  - WDDisable

  - WDExclusion

- Tasks

  - GetKeylogger
  - Open Url (Visible - Invisible)
  - Recovery
  - Run File (Disk - Link - Memory)
  - DiscordToken
  - TelegramSession
  - MetaMask
  - WDExclusion
  - Update All Clients

- **Drag And Drop Files**
  <b>

  - File Manager
  - Monitor
  - HVNC

  </b>

</b>

## Builder

<b>
  
- Schtasks 
- Startup 
- Registry (Change Path)
- Multi Dns
- TBotNotify
- AntiKill
- WDEX
- Keylogger
- Clipper
- Sleep
- Obfuscator
- AntiAnalysis
- USB Spread 
- Icon 
- Assembly

- **Icon Pack**

</b>

## Connection

<b>

- Stable Connection
- Encrypted Connection
- Encrypted Strings

</b>

## Extra Tools

<b>

- Fud Downloader (HTA)
- Check Port
- Icon Changer
- Multi Binder (Icon - Assembly - Obfuscator)

</b>

## Requirements

<b>
  
.Net Framework 4.5 [Controller]

.Net Framework 4.0 [Client]

Size : 49.0 KB [Full Features]

Best Software Quality Ever

</b>

## Overview

![videos](https://github.com/user-attachments/assets/afe5a729-4459-4876-9ba6-6ed07a73565e)

## Notes

- This code is provided for learning and experimentation purposes only.

## Author

[XCoder](https://github.com/)

## Disclaimer

**This content is provided for learning and testing purposes only. The information presented is for general information purposes and does not address any specific situation. No warranty is given as to the timeliness, accuracy or completeness of the information contained in the content. In connection with the use of these materials, no liability is accepted for any consequences or damages that may result from the use of the information or recommendations contained in the content.**

## License

This project is licensed under the MIT License. For more information, see the [LICENSE file](LICENSE).
